<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentPurchase extends Model
{
    protected $table='student_purchases';
}
