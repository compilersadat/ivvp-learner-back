<?php $__env->startSection('content'); ?>
<div class="col-lg-6">
    <div class="card">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-header"><strong>EDIT BOOK</strong></div>
         <div class="card-body card-block">
            <form method="POST" action="<?php echo e(route('ebook.update', $ebook->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                 <?php echo method_field('PATCH'); ?>
                
                 <div class="form-group">
                  <label for="branch" class=" form-control-label">Select Branch</label>
                 
                    <select class="form-control" name="branch_id">
                      <option value=""><?php echo e(__('Select Branch')); ?></option>
                      <?php $__currentLoopData = @App\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>" <?php echo e(($ebook->branch_id == $row->id) ? "selected" : ''); ?>><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  
                </div>

                <div class="form-group">
                  <label for="faculty" class=" form-control-label">Select Faculty</label>
                  
                    <select class="form-control" name="faculty_id">
                      <option value=""><?php echo e(__('Select Faculty')); ?></option>
                      <?php $__currentLoopData = @App\Faculty::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>" <?php echo e(($ebook->faculty_id == $row->id) ? "selected" : ''); ?>><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  
                </div>


     <div class="form-group">
         <label for="ebook" class=" form-control-label">Book Name</label>
        <input type="text" id="ebook" name="name" placeholder="Book name" value="<?php echo e($ebook->name); ?>" class="form-control">
     </div>


     <div class="form-group">
        <label for="vat" class=" form-control-label">Price</label>
        <input type="text" id="price" name="price" placeholder="Price" value="<?php echo e($ebook->price); ?>" class="form-control">
     </div>

     <div class="form-group">
        <label for="vat" class=" form-control-label">Image</label>
        <input type="file" id="image" name="image" placeholder="Image" class="form-control">
     </div> 

     <div class="form-group">
      <label class="form-label">Description</label>
      <textarea class="form-control" name="description" placeholder="Description">
        <?php echo e($ebook->description); ?>

      </textarea>
    </div>
        
     <div class="card">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>

                                            
     </div>
 </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/ebooks/edit.blade.php ENDPATH**/ ?>