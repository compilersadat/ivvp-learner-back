<?php $__env->startSection('content'); ?>

<div class="col-md-6">
    <h3 class="card-title">Chapter Details:</h3>
</div>
<div class="list-group">
    
    <?php $__currentLoopData = $chapter_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="list-group-item">
        <div class="row">
            <div class="col-md-2">Page No</div>
            <div class="col-md-8"><?php echo e($row->page_no); ?></div>
        </div>
    </div>

    <div class="list-group-item">
        <div class="row">
            
            <div class="col-md-8"><?php echo e($row->data); ?></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/ebooks/chapter_data.blade.php ENDPATH**/ ?>