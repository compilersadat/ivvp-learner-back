<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col">
      <?php if($errors->any()): ?>
                     <div class="alert alert-danger">
                         <ul>
                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><?php echo e($error); ?></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                     </div>
                 <?php endif; ?>
                 <?php if(session('success')): ?>
                     <div class="alert alert-success">
                         <?php echo e(session('success')); ?>

                     </div>
                 <?php endif; ?>
   </div>
   
 </div>

  <div class="col-lg-8s">
    <div class="card">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-header"><strong>ADD NEW BOOK</strong></div>
        <div class="card-body card-block">
            <form method="POST" action="<?php echo e(route('ebook.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="faculty" class=" form-control-label">Select Book Type</label>
                    <select class="form-control" name="book_type">
                      <option value=""><?php echo e(__('Select Book Type')); ?></option>
                      <option value="theory">Theory</option>
                      <option value="objective">Objective</option>
                    
                    </select>
                </div>

                <div class="form-group">
                  <label for="faculty" class=" form-control-label">Select Faculty</label>
                    <select class="form-control" name="faculty_id">
                      <option value=""><?php echo e(__('Select Faculty')); ?></option>
                      <?php $__currentLoopData = @App\Faculty::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                <div class="form-group">
                  <label for="branch" class=" form-control-label">Select Branch</label>
                    <select class="form-control" name="branch_id">
                      <option value=""><?php echo e(__('Select Branch')); ?></option>
                      <?php $__currentLoopData = @App\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                

     <div class="form-group">
       
         <label for="ebook" class=" form-control-label">Book Name</label>
        <input type="text" id="ebook" name="name" placeholder="Book name" class="form-control">
     </div>

     

     <div class="form-group">
        <label for="vat" class=" form-control-label">Price</label>
        <input type="text" id="price" name="price" placeholder="Price" class="form-control">
     </div>

     <div class="form-group">
        <label for="vat" class=" form-control-label">Image</label>
        <input type="file" id="image" name="image" placeholder="Image" class="form-control">
     </div> 

     <div class="form-group">
        <label class="form-label">Description</label>
        <textarea id="editor1" class="form-control" rows="5" cols="40" name="description"
                  placeholder="Description">
        </textarea>
      </div>


     <div class="card">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>                                      
     </div>
 </div>
</div>
<script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
<script>
  CKEDITOR.replace( 'editor1' );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/ebooks/create.blade.php ENDPATH**/ ?>