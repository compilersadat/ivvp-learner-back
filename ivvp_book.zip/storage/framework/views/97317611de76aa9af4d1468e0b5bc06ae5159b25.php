<?php $__env->startSection('content'); ?>

 <div class="col-md-6">
            <h3 class="card-title">Book Details:</h3>
 </div>
<div class="list-group">
        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Book Type</div>
                <div class="col-md-8"><?php echo e($ebook->book_type); ?></div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Book Name</div>
                <div class="col-md-8"><?php echo e($ebook->name); ?></div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Chapter Name</div>
                
                <div class="col-md-4">
                    <?php $__currentLoopData = @App\Chapter::where('book_id', $ebook->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('chapter-data', $row->id)); ?>"><?php echo e($row->chapter_name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Book Image</div>
                <div class="col-md-4"><img src="<?php echo e(asset('site/storage/app/ebook/'.$ebook->image)); ?>" class="" width="100"></div>
            </div>
        </div>


        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Description</div>
                <div class="col-md-8"><?php echo $ebook->description; ?></div>
            </div>
        </div>



        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Created At</div>
                <div class="col-md-8"><?php echo e($ebook->created_at); ?></div>
            </div>
        </div>

        <div class="list-group-item">
            <div class="row">
                <div class="col-md-2">Updated At</div>
                <div class="col-md-8"><?php echo e($ebook->updated_at); ?></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/ebooks/show.blade.php ENDPATH**/ ?>