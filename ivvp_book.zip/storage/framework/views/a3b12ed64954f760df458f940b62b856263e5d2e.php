<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col">
      <?php if($errors->any()): ?>
                     <div class="alert alert-danger">
                         <ul>
                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><?php echo e($error); ?></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                     </div>
                 <?php endif; ?>
                 <?php if(session('success')): ?>
                     <div class="alert alert-success">
                         <?php echo e(session('success')); ?>

                     </div>
                 <?php endif; ?>
   </div>
   
 </div>

  <div class="col-lg-6">
    <div class="card">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-header"><strong>ADD NEW STUDENT PURCHASE</strong></div>
        <div class="card-body card-block">
            <form method="POST" action="<?php echo e(route('student-purchase.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>


     <div class="form-group">
       
         <label for="date" class=" form-control-label">Date</label>
        <input type="date" id="date" name="date" placeholder="Date" class="form-control">
     </div>



     <div class="card">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>                                      
     </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/student_purchase/create.blade.php ENDPATH**/ ?>