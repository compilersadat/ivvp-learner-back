<?php $__env->startSection('content'); ?>

  <div class="content">
     <div class="row">
    <div class="col-md-12 text-left">
            <a href="<?php echo e(route('ebook.create')); ?>" class=" btn btn-sm btn-primary"><i class="fa fa-plus"></i> Create New </a><br>
          </div>
</div>
            <div class="animated fadeIn">
                <div class="row">
                    <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">All Book List</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                        	<th>SR NO</th>
                                            <th>Book Name</th>
                                            <th>Branch </th>
                                            <th>Faculty</th>
                                            <th>Price</th>
                                            <th>Image</th>
                                            
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                     <?php $i=1;?>
						              <?php $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						              <tr>
						               <td><?php echo e($i); ?></td>
						               <td><?php echo e($row->name); ?></td>
						               <td><?php echo e(@App\Branch::where('id', $row->branch_id)->value('name')); ?></td>
                                       <td><?php echo e(@App\Faculty::where('id', $row->faculty_id)->value('name')); ?></td>
                                       <td><?php echo e($row->price); ?></td>
                                       <td><img src="<?php echo e(asset('site/storage/app/ebook/'.$row->image)); ?>" class="" width="100"></td>
                                       
						               <td>
						                  <a href="<?php echo e(route('ebook.edit',$row->id)); ?>" class="label  "><i class="fa fa-edit fa-1x" style="color: #000"></i> </a>
						                  <a href="<?php echo e(route('ebook.delete',$row->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="label bg-red-active"><i class="fa fa-trash  fa-1x" style="color: #000"></i> </a>
						                  <a href="<?php echo e(route('ebook.show',$row->id)); ?>"><span class="label "><i class="fa fa-eye  fa-1x" style="color: #000"></i>&ensp;</span></a>
						               </td>
						              </tr>
						            <?php $i++?>
						             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div><!-- .animated -->
        </div>
    <script src="<?php echo e(asset('js/lib/data-table/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/buttons.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/data-table/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init/datatables-init.js')); ?>"></script>
         <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/ebooks/index.blade.php ENDPATH**/ ?>