<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col">
      <?php if($errors->any()): ?>
                     <div class="alert alert-danger">
                         <ul>
                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><?php echo e($error); ?></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                     </div>
                 <?php endif; ?>
                 <?php if(session('success')): ?>
                     <div class="alert alert-success">
                         <?php echo e(session('success')); ?>

                     </div>
                 <?php endif; ?>
   </div>
   
 </div>

  <div class="col-lg-6">
    <div class="card">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card-header"><strong>ADD NEW CHAPTER</strong></div>
        <div class="card-body card-block">
            <form method="POST" action="<?php echo e(route('chapter.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="book" class=" form-control-label">Select Book</label>
                 
                    <select class="form-control" name="book_id">
                      <option value=""><?php echo e(__('Select Book')); ?></option>
                      <?php $__currentLoopData = @App\Ebook::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  
                </div>



     <div class="form-group">
         <label for="chname" class=" form-control-label">Chapter Name</label>
        <input type="text" id="chname" name="chapter_name" placeholder="Chapter name" class="form-control">
     </div>

     


     <div class="card">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>                                      
     </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IvvpBooks\resources\views/admin/chapters/create.blade.php ENDPATH**/ ?>